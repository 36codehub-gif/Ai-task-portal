package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Accents
val CyberCyan = Color(0xFF00E5FF)
val DeepNavy = Color(0xFF0B132B)
val MidnightNavy = Color(0xFF1C2541)
val SlateNavy = Color(0xFF3A506B)
val ElectricBlue = Color(0xFF2563EB)
val VividViolet = Color(0xFF7C3AED)
val NeonEmerald = Color(0xFF10B981)
val AmberAlert = Color(0xFFF59E0B)

// Dark Theme Palette
val DarkBg = Color(0xFF080D1A)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkBorder = Color(0xFF374151)
val DarkOnSurface = Color(0xFFF9FAFB)
val DarkOnSurfaceSubtle = Color(0xFF9CA3AF)

// Light Theme Palette
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceSubtle = Color(0xFF64748B)

// Badges
val FresherBadgeBg = Color(0xFFFEF3C7)
val FresherBadgeText = Color(0xFFB45309)
val RemoteBadgeBg = Color(0xFFDCFCE7)
val RemoteBadgeText = Color(0xFF15803D)
val IndiaBadgeBg = Color(0xFFE0F2FE)
val IndiaBadgeText = Color(0xFF0369A1)
val MNCBadgeBg = Color(0xFFEDE9FE)
val MNCBadgeText = Color(0xFF6D28D9)
