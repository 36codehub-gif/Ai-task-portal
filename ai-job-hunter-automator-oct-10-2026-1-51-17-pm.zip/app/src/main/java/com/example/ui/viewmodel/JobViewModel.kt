package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.automation.ScheduleManager
import com.example.data.local.PreferencesManager
import com.example.data.model.DailyDigest
import com.example.data.model.JobPost
import com.example.data.repository.JobRepository
import com.example.email.GmailDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class JobFilter(val label: String) {
    ALL("All Roles"),
    FRESHERS("Freshers / 0 YOE"),
    ONE_TO_TWO("0–2 YOE"),
    REMOTE("Remote Worldwide"),
    INDIA("India"),
    STARTUPS("AI Startups"),
    MNCS("Tech Giants / MNCs")
}

data class JobUiState(
    val allJobs: List<JobPost> = emptyList(),
    val filteredJobs: List<JobPost> = emptyList(),
    val savedJobs: List<JobPost> = emptyList(),
    val appliedJobs: List<JobPost> = emptyList(),
    val latestDigest: DailyDigest? = null,
    val allDigests: List<DailyDigest> = emptyList(),
    val isScanning: Boolean = false,
    val searchQuery: String = "",
    val activeFilter: JobFilter = JobFilter.ALL,
    val targetEmail: String = PreferencesManager.DEFAULT_EMAIL,
    val isAutomationEnabled: Boolean = true,
    val scheduleHourIst: Int = PreferencesManager.DEFAULT_HOUR_IST,
    val scheduleMinuteIst: Int = PreferencesManager.DEFAULT_MINUTE_IST,
    val searchIndia: Boolean = true,
    val searchRemote: Boolean = true,
    val filterFreshersOnly: Boolean = false,
    val lastRunSummary: String = "",
    val remainingTimeIst: String = "8:00 AM IST",
    val statusMessage: String? = null
)

private data class FilterState(
    val query: String,
    val filter: JobFilter,
    val isScanning: Boolean,
    val trigger: Int
)

class JobViewModel(
    private val repository: JobRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _isScanning = MutableStateFlow(false)
    private val _searchQuery = MutableStateFlow("")
    private val _activeFilter = MutableStateFlow(JobFilter.ALL)
    private val _statusMessage = MutableStateFlow<String?>(null)
    private val _previewDigest = MutableStateFlow<DailyDigest?>(null)
    val previewDigest: StateFlow<DailyDigest?> = _previewDigest.asStateFlow()

    private val _refreshTrigger = MutableStateFlow(0)

    private val filterStateFlow = combine(
        _searchQuery,
        _activeFilter,
        _isScanning,
        _refreshTrigger
    ) { query, filter, isScanning, trigger ->
        FilterState(query, filter, isScanning, trigger)
    }

    val uiState: StateFlow<JobUiState> = combine(
        repository.allJobs,
        repository.latestDigest,
        repository.allDigests,
        filterStateFlow
    ) { jobs: List<JobPost>, latestDigest: DailyDigest?, digests: List<DailyDigest>, filterState: FilterState ->
        val query = filterState.query
        val filter = filterState.filter
        val scanning = filterState.isScanning

        val filtered = jobs.filter { job ->
            val matchesQuery = if (query.isBlank()) true else {
                job.title.contains(query, ignoreCase = true) ||
                job.company.contains(query, ignoreCase = true) ||
                job.skills.contains(query, ignoreCase = true) ||
                job.location.contains(query, ignoreCase = true)
            }

            val matchesFilter = when (filter) {
                JobFilter.ALL -> true
                JobFilter.FRESHERS -> job.minYoe == 0 && (job.experienceLevel.contains("Fresher", ignoreCase = true) || job.maxYoe <= 1)
                JobFilter.ONE_TO_TWO -> job.maxYoe <= 2
                JobFilter.REMOTE -> job.isRemote
                JobFilter.INDIA -> job.location.contains("India", ignoreCase = true)
                JobFilter.STARTUPS -> job.companyType.contains("Startup", ignoreCase = true)
                JobFilter.MNCS -> job.companyType.contains("MNC", ignoreCase = true) || job.companyType.contains("Giant", ignoreCase = true)
            }

            matchesQuery && matchesFilter
        }

        val saved = jobs.filter { it.isSaved }
        val applied = jobs.filter { it.applicationStatus == JobPost.STATUS_APPLIED }
        val hourIst = preferencesManager.getScheduleHourIst()
        val minIst = preferencesManager.getScheduleMinuteIst()

        JobUiState(
            allJobs = jobs,
            filteredJobs = filtered,
            savedJobs = saved,
            appliedJobs = applied,
            latestDigest = latestDigest,
            allDigests = digests,
            isScanning = scanning,
            searchQuery = query,
            activeFilter = filter,
            targetEmail = preferencesManager.getTargetEmail(),
            isAutomationEnabled = preferencesManager.isAutomationEnabled(),
            scheduleHourIst = hourIst,
            scheduleMinuteIst = minIst,
            searchIndia = preferencesManager.isSearchIndia(),
            searchRemote = preferencesManager.isSearchRemote(),
            filterFreshersOnly = preferencesManager.isFilterFreshersOnly(),
            lastRunSummary = preferencesManager.getLastRunSummary(),
            remainingTimeIst = ScheduleManager.getRemainingTimeFormatted(hourIst, minIst),
            statusMessage = _statusMessage.value
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = JobUiState()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: JobFilter) {
        _activeFilter.value = filter
    }

    fun triggerScan(forceLive: Boolean = true) {
        viewModelScope.launch {
            _isScanning.value = true
            _statusMessage.value = "Scanning web for 0-2 YOE AI Engineering roles in India & Remote..."
            try {
                val newDigest = repository.triggerDailySearch(forceLive)
                _statusMessage.value = "Automation complete: Discovered ${newDigest.totalJobs} verified roles."
            } catch (e: Exception) {
                _statusMessage.value = "Scan error: ${e.message}"
            } finally {
                _isScanning.value = false
                _refreshTrigger.value += 1
            }
        }
    }

    fun toggleSaveJob(job: JobPost) {
        viewModelScope.launch {
            repository.toggleJobSave(job.id, !job.isSaved)
        }
    }

    fun updateJobStatus(job: JobPost, status: String) {
        viewModelScope.launch {
            repository.updateJobApplicationStatus(job.id, status)
        }
    }

    fun sendDigestViaGmail(context: Context, digest: DailyDigest? = null) {
        val targetDigest = digest ?: uiState.value.latestDigest ?: return
        val subject = "🎯 Daily AI Engineering Job Digest - ${targetDigest.dateString} (0-2 YOE | India & Remote)"

        GmailDispatcher.sendViaGmail(
            context = context,
            recipient = targetDigest.recipientEmail,
            subject = subject,
            bodyHtml = targetDigest.emailContentHtml,
            bodyText = targetDigest.emailContentText
        )

        viewModelScope.launch {
            repository.markDigestSentToGmail(targetDigest.id)
            _refreshTrigger.value += 1
        }
    }

    fun setPreviewDigest(digest: DailyDigest?) {
        _previewDigest.value = digest
    }

    fun updateTargetEmail(email: String) {
        preferencesManager.setTargetEmail(email.trim())
        _refreshTrigger.value += 1
    }

    fun updateScheduleTime(context: Context, hourIst: Int, minuteIst: Int) {
        preferencesManager.setScheduleTimeIst(hourIst, minuteIst)
        ScheduleManager.scheduleDailyAlarm(context)
        _refreshTrigger.value += 1
    }

    fun toggleAutomation(context: Context, enabled: Boolean) {
        preferencesManager.setAutomationEnabled(enabled)
        if (enabled) {
            ScheduleManager.scheduleDailyAlarm(context)
        } else {
            ScheduleManager.cancelAlarm(context)
        }
        _refreshTrigger.value += 1
    }

    fun updateSearchPreferences(searchIndia: Boolean, searchRemote: Boolean, freshersOnly: Boolean) {
        preferencesManager.setSearchIndia(searchIndia)
        preferencesManager.setSearchRemote(searchRemote)
        preferencesManager.setFilterFreshersOnly(freshersOnly)
        _refreshTrigger.value += 1
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    class Factory(
        private val repository: JobRepository,
        private val preferencesManager: PreferencesManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return JobViewModel(repository, preferencesManager) as T
        }
    }
}
