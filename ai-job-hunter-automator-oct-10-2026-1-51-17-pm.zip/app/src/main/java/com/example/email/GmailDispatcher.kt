package com.example.email

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.text.Html
import android.widget.Toast
import com.example.data.model.DailyDigest
import com.example.data.model.JobPost
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GmailDispatcher {

    fun generateEmailDigest(
        jobs: List<JobPost>,
        dateStr: String = SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.US).format(Date()),
        targetEmail: String = "mannewarsachin@gmail.com"
    ): Pair<String, String> {
        val fresherCount = jobs.count { it.minYoe == 0 && (it.experienceLevel.contains("Fresher", ignoreCase = true) || it.maxYoe <= 1) }
        val remoteCount = jobs.count { it.isRemote }
        val indiaCount = jobs.count { it.location.contains("India", ignoreCase = true) }

        // 1. Generate Plain Text / Markdown Format
        val plainText = buildString {
            appendLine("═══════════════════════════════════════════════════════════════")
            appendLine("🎯 DAILY AI ENGINEERING JOB DIGEST — $dateStr")
            appendLine("Prioritizing Freshers & 0–2 YOE | India & Remote Worldwide")
            appendLine("Target Recipient: $targetEmail")
            appendLine("═══════════════════════════════════════════════════════════════")
            appendLine()
            appendLine("📊 EXECUTIVE BRIEFING:")
            appendLine("• Total Curated Roles: ${jobs.size}")
            appendLine("• Freshers / 0 YOE Friendly: $fresherCount roles")
            appendLine("• Remote Worldwide: $remoteCount roles")
            appendLine("• India Tech Hubs: $indiaCount roles")
            appendLine("• Core Demand: PyTorch, LangChain/LangGraph, RAG, Transformers, vLLM, Fine-tuning")
            appendLine()
            appendLine("───────────────────────────────────────────────────────────────")
            appendLine("📋 VERIFIED DIRECT ROLES (${jobs.size}):")
            appendLine("───────────────────────────────────────────────────────────────")

            jobs.forEachIndexed { index, job ->
                appendLine()
                appendLine("${index + 1}. ${job.title.uppercase()}")
                appendLine("   Company:      ${job.company} (${job.companyType})")
                appendLine("   Location:     ${job.location} ${if (job.isRemote) "[REMOTE]" else ""}")
                appendLine("   Experience:   ${job.experienceLevel} (Max YOE: ${job.maxYoe})")
                appendLine("   Salary Band:  ${job.salaryBand}")
                appendLine("   Posting Date: ${job.postingDate}")
                appendLine("   Eligibility:  ${job.eligibility}")
                appendLine("   Skills:       ${job.skills}")
                appendLine("   Summary:      ${job.descriptionSummary}")
                appendLine("   Direct Apply: ${job.directApplyUrl}")
                appendLine("   ------------------------------------------------------------")
            }

            appendLine()
            appendLine("💡 ATS & INTERVIEW TIP FOR FRESHERS:")
            appendLine("Highlight personal projects integrating open-source LLMs (e.g. Llama-3, DeepSeek) with RAG and vector databases (Pinecone/Chroma/Qdrant) on GitHub. Recruiters value production latency awareness.")
            appendLine()
            appendLine("Generated automatically at 8:00 AM IST by AI Job Scout.")
        }

        // 2. Generate Rich HTML Format for Gmail
        val htmlContent = buildString {
            append("""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f4f6f9; color: #1a202c; margin: 0; padding: 20px; line-height: 1.6; }
  .container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.06); }
  .header { background: linear-gradient(135deg, #0b132b 0%, #1c2541 100%); color: #ffffff; padding: 30px 24px; text-align: center; }
  .badge { display: inline-block; background: #00e5ff; color: #0b132b; font-size: 11px; font-weight: 700; text-transform: uppercase; padding: 4px 10px; border-radius: 20px; letter-spacing: 0.5px; margin-bottom: 12px; }
  .header h1 { margin: 0 0 8px 0; font-size: 24px; font-weight: 700; color: #ffffff; }
  .header p { margin: 0; color: #cbd5e1; font-size: 14px; }
  .stats-grid { display: flex; background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 16px 20px; justify-content: space-around; text-align: center; }
  .stat-item { flex: 1; }
  .stat-val { font-size: 20px; font-weight: 700; color: #0b132b; }
  .stat-lbl { font-size: 11px; color: #64748b; text-transform: uppercase; font-weight: 600; margin-top: 2px; }
  .content { padding: 24px; }
  .section-title { font-size: 16px; font-weight: 700; color: #1e293b; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 16px 0; border-left: 4px solid #00e5ff; padding-left: 10px; }
  .job-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; margin-bottom: 18px; box-shadow: 0 2px 6px rgba(0,0,0,0.02); }
  .job-title { font-size: 18px; font-weight: 700; color: #0f172a; margin: 0 0 4px 0; }
  .company-name { font-size: 14px; font-weight: 600; color: #3b82f6; margin-bottom: 12px; }
  .meta-tag { display: inline-block; background: #e0f2fe; color: #0369a1; font-size: 12px; font-weight: 600; padding: 3px 8px; border-radius: 6px; margin-right: 6px; margin-bottom: 8px; }
  .tag-remote { background: #dcfce7; color: #15803d; }
  .tag-fresher { background: #fef3c7; color: #b45309; }
  .job-detail { font-size: 13px; color: #475569; margin: 6px 0; }
  .job-detail strong { color: #1e293b; }
  .skills-row { margin: 10px 0; }
  .skill-pill { display: inline-block; background: #f1f5f9; color: #334155; font-size: 11px; padding: 2px 7px; border-radius: 4px; margin-right: 4px; margin-bottom: 4px; border: 1px solid #e2e8f0; }
  .apply-btn { display: inline-block; background: #0b132b; color: #ffffff !important; text-decoration: none; font-size: 13px; font-weight: 600; padding: 10px 20px; border-radius: 6px; margin-top: 12px; }
  .tip-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 16px; margin-top: 24px; }
  .tip-title { font-size: 13px; font-weight: 700; color: #166534; margin-bottom: 4px; }
  .tip-text { font-size: 12px; color: #15803d; margin: 0; }
  .footer { background: #f8fafc; padding: 20px; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="badge">Daily AI Automation • 8:00 AM IST</div>
    <h1>AI Engineering Job Digest</h1>
    <p>$dateStr • Curated for Freshers & 0–2 YOE</p>
  </div>
  <table class="stats-grid" width="100%">
    <tr>
      <td class="stat-item"><div class="stat-val">${jobs.size}</div><div class="stat-lbl">Roles</div></td>
      <td class="stat-item"><div class="stat-val">$fresherCount</div><div class="stat-lbl">Freshers / 0 YOE</div></td>
      <td class="stat-item"><div class="stat-val">$remoteCount</div><div class="stat-lbl">Remote</div></td>
      <td class="stat-item"><div class="stat-val">$indiaCount</div><div class="stat-lbl">India</div></td>
    </tr>
  </table>
  <div class="content">
    <div class="section-title">Verified High-Signal Roles</div>
            """.trimIndent())

            jobs.forEach { job ->
                val isRemoteTag = if (job.isRemote) "<span class=\"meta-tag tag-remote\">Remote Worldwide</span>" else "<span class=\"meta-tag\">${job.location}</span>"
                val isFresherTag = if (job.minYoe == 0) "<span class=\"meta-tag tag-fresher\">${job.experienceLevel}</span>" else "<span class=\"meta-tag\">${job.experienceLevel}</span>"

                val skillsHtml = job.getSkillList().joinToString(" ") { skill ->
                    "<span class=\"skill-pill\">$skill</span>"
                }

                append("""
    <div class="job-card">
      <div class="job-title">${job.title}</div>
      <div class="company-name">${job.company} &bull; ${job.companyType}</div>
      <div>
        $isRemoteTag
        $isFresherTag
        <span class="meta-tag">${job.salaryBand}</span>
        <span class="meta-tag">${job.postingDate}</span>
      </div>
      <div class="job-detail"><strong>Eligibility:</strong> ${job.eligibility}</div>
      <div class="job-detail"><strong>Focus:</strong> ${job.descriptionSummary}</div>
      <div class="skills-row"><strong>Skills:</strong> $skillsHtml</div>
      <a href="${job.directApplyUrl}" class="apply-btn" target="_blank">Direct Apply &rarr;</a>
    </div>
                """.trimIndent())
            }

            append("""
    <div class="tip-box">
      <div class="tip-title">⚡ Freshers & 0-2 YOE Application Strategy</div>
      <p class="tip-text">Demonstrate hands-on RAG systems, model evaluation with benchmarks, and latency profiling on GitHub. Include links directly at the top of your resume.</p>
    </div>
  </div>
  <div class="footer">
    Sent automatically by AI Job Scout to <strong>$targetEmail</strong><br>
    Configured Daily Run: 8:00 AM IST
  </div>
</div>
</body>
</html>
            """.trimIndent())
        }

        return Pair(plainText, htmlContent)
    }

    fun sendViaGmail(
        context: Context,
        recipient: String,
        subject: String,
        bodyHtml: String,
        bodyText: String
    ) {
        val spannableBody = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(bodyHtml, Html.FROM_HTML_MODE_LEGACY)
        } else {
            @Suppress("DEPRECATION")
            Html.fromHtml(bodyHtml)
        }

        // Try direct launch into official Gmail App
        val gmailIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            setPackage("com.google.android.gm")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, spannableBody)
            putExtra(Intent.EXTRA_HTML_TEXT, bodyHtml)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            val activities = context.packageManager.queryIntentActivities(gmailIntent, 0)
            if (activities.isNotEmpty()) {
                context.startActivity(gmailIntent)
                Toast.makeText(context, "Opening Gmail with pre-filled digest...", Toast.LENGTH_SHORT).show()
                return
            }
        } catch (e: Exception) {
            // Gmail package check failed, fallback to mailto or chooser
        }

        // Fallback: Mailto / Standard Email Chooser
        try {
            val mailtoUri = Uri.parse("mailto:$recipient")
            val emailIntent = Intent(Intent.ACTION_SENDTO, mailtoUri).apply {
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, bodyText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(emailIntent, "Send AI Jobs Digest via...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            // Generic send fallback
            try {
                val genericIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                    putExtra(Intent.EXTRA_SUBJECT, subject)
                    putExtra(Intent.EXTRA_TEXT, bodyText)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(genericIntent, "Send Digest via...").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (ex: Exception) {
                Toast.makeText(context, "No email client found. Copied to clipboard!", Toast.LENGTH_LONG).show()
                copyToClipboard(context, bodyText)
            }
        }
    }

    fun copyToClipboard(context: Context, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("AI Engineering Job Digest", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Daily Digest copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    fun shareDigest(context: Context, subject: String, text: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Daily AI Job Digest").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
