package com.example

import android.app.Application
import com.example.automation.ScheduleManager
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.repository.JobRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JobScoutApplication : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var preferencesManager: PreferencesManager
        private set
    lateinit var repository: JobRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        preferencesManager = PreferencesManager(this)
        repository = JobRepository(database, preferencesManager)

        CoroutineScope(Dispatchers.IO).launch {
            repository.initializeDataIfNeeded()
            ScheduleManager.scheduleDailyAlarm(this@JobScoutApplication)
        }
    }
}
