package com.example.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.PreferencesManager
import java.util.Calendar
import java.util.TimeZone

object ScheduleManager {
    const val REQUEST_CODE_DAILY_ALARM = 8001
    val IST_TIME_ZONE: TimeZone = TimeZone.getTimeZone("GMT+05:30")

    fun scheduleDailyAlarm(context: Context) {
        val prefs = PreferencesManager(context)
        if (!prefs.isAutomationEnabled()) {
            cancelAlarm(context)
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val hourIst = prefs.getScheduleHourIst()
        val minuteIst = prefs.getScheduleMinuteIst()

        val nextTriggerMillis = calculateNextTriggerMillis(hourIst, minuteIst)

        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_DAILY_ALARM,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    nextTriggerMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    nextTriggerMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // In Android 12+ if exact alarm permission is restricted, fallback to standard set
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                nextTriggerMillis,
                pendingIntent
            )
        }
    }

    fun cancelAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_DAILY_ALARM,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun calculateNextTriggerMillis(hourIst: Int, minuteIst: Int): Long {
        val now = System.currentTimeMillis()
        val targetCal = Calendar.getInstance(IST_TIME_ZONE).apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hourIst)
            set(Calendar.MINUTE, minuteIst)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (targetCal.timeInMillis <= now) {
            targetCal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return targetCal.timeInMillis
    }

    fun getRemainingTimeFormatted(hourIst: Int, minuteIst: Int): String {
        val nextMillis = calculateNextTriggerMillis(hourIst, minuteIst)
        val diff = nextMillis - System.currentTimeMillis()
        if (diff <= 0) return "Due right now"

        val hours = diff / (1000 * 60 * 60)
        val minutes = (diff / (1000 * 60)) % 60
        return "${hours}h ${minutes}m"
    }
}
