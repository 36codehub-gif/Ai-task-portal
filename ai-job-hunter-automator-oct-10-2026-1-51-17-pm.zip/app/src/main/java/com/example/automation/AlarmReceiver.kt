package com.example.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.repository.JobRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "ai_job_scout_daily_channel"
        const val NOTIFICATION_ID = 9001
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val database = AppDatabase.getDatabase(context)
                val prefs = PreferencesManager(context)
                val repository = JobRepository(database, prefs)

                // Trigger automation search & digest generation
                val digest = repository.triggerDailySearch(forceLive = true)

                // Show Notification
                showDailyDigestNotification(context, digest.totalJobs, prefs.getTargetEmail())

                // Reschedule for next day at 8:00 AM IST
                ScheduleManager.scheduleDailyAlarm(context)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showDailyDigestNotification(context: Context, totalJobs: Int, targetEmail: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Daily AI Job Scout Digest",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily 8:00 AM IST notification for entry-level AI engineering roles"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_ACTION", "OPEN_DIGEST")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("🎯 8:00 AM IST: Daily AI Job Digest Ready!")
            .setContentText("Found $totalJobs verified 0–2 YOE roles. Ready to send to $targetEmail.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "Your automated AI Engineering search discovered $totalJobs verified roles for Freshers & 0-2 YOE across India & Remote. Tap to open and send via Gmail."
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_dialog_email,
                "Send to Gmail",
                pendingIntent
            )
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }
}
