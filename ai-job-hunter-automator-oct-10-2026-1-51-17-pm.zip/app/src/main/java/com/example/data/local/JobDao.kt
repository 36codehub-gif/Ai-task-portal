package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.JobPost
import kotlinx.coroutines.flow.Flow

@Dao
interface JobDao {
    @Query("SELECT * FROM jobs ORDER BY discoveredAt DESC")
    fun getAllJobs(): Flow<List<JobPost>>

    @Query("SELECT * FROM jobs WHERE isSaved = 1 ORDER BY discoveredAt DESC")
    fun getSavedJobs(): Flow<List<JobPost>>

    @Query("SELECT * FROM jobs WHERE applicationStatus = :status ORDER BY discoveredAt DESC")
    fun getJobsByStatus(status: String): Flow<List<JobPost>>

    @Query("SELECT * FROM jobs WHERE maxYoe <= :maxYoe ORDER BY discoveredAt DESC")
    fun getJobsByMaxYoe(maxYoe: Int): Flow<List<JobPost>>

    @Query("SELECT * FROM jobs WHERE isRemote = 1 ORDER BY discoveredAt DESC")
    fun getRemoteJobs(): Flow<List<JobPost>>

    @Query("SELECT * FROM jobs WHERE location LIKE '%India%' ORDER BY discoveredAt DESC")
    fun getIndiaJobs(): Flow<List<JobPost>>

    @Query("SELECT * FROM jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJobById(jobId: String): JobPost?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertJobs(jobs: List<JobPost>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateJob(job: JobPost)

    @Update
    suspend fun updateJob(job: JobPost)

    @Delete
    suspend fun deleteJob(job: JobPost)

    @Query("UPDATE jobs SET isSaved = :isSaved WHERE id = :jobId")
    suspend fun updateSaveStatus(jobId: String, isSaved: Boolean)

    @Query("UPDATE jobs SET applicationStatus = :status, appliedDate = :appliedDate WHERE id = :jobId")
    suspend fun updateApplicationStatus(jobId: String, status: String, appliedDate: Long?)

    @Query("SELECT COUNT(*) FROM jobs")
    suspend fun getTotalJobCount(): Int
}
