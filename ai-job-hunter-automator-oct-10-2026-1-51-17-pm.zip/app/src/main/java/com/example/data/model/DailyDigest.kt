package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "digests")
data class DailyDigest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateString: String,
    val headline: String,
    val executiveSummary: String,
    val totalJobs: Int,
    val fresherRolesCount: Int,
    val remoteRolesCount: Int,
    val indiaRolesCount: Int,
    val topHiringTech: String, // e.g., "PyTorch, LangChain, RAG, Llama-3 Fine-tuning"
    val emailContentHtml: String,
    val emailContentText: String,
    val recipientEmail: String = "mannewarsachin@gmail.com",
    val status: String = STATUS_GENERATED, // "GENERATED", "SENT_GMAIL", "DISMISSED"
    val runTimestamp: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_GENERATED = "GENERATED"
        const val STATUS_SENT_GMAIL = "SENT_GMAIL"
    }
}
