package com.example.data.remote

import com.example.BuildConfig
import com.example.data.model.JobPost
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.UUID
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @field:Json(name = "contents") val contents: List<GeminiContent>,
    @field:Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @field:Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @field:Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    @field:Json(name = "temperature") val temperature: Float? = 0.2f,
    @field:Json(name = "responseMimeType") val responseMimeType: String? = "application/json"
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @field:Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @field:Json(name = "content") val content: GeminiContent? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    suspend fun searchLiveJobs(
        searchIndia: Boolean = true,
        searchRemote: Boolean = true,
        freshersOnly: Boolean = false
    ): List<JobPost> {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Return curated jobs if key is placeholder or empty
            return CuratedJobsData.getInitialCuratedJobs()
        }

        val prompt = buildString {
            append("You are an expert AI & ML Technical Recruiter and Career Scout. ")
            append("Search and generate current entry-level AI Engineering, Junior AI Engineer, ML Engineer, Generative AI, LLM and Applied AI job roles at strong tech startups and MNCs. ")
            append("Target audience: Freshers and 0-2 years of experience. ")
            if (searchIndia && searchRemote) {
                append("Locations must be either in India (Bengaluru, Hyderabad, Pune, Gurugram, etc.) or Remote worldwide. ")
            } else if (searchIndia) {
                append("Locations must strictly be in India (Bengaluru, Hyderabad, Pune, etc.). ")
            } else if (searchRemote) {
                append("Locations must strictly be Remote Worldwide. ")
            }
            if (freshersOnly) {
                append("Prioritize candidates with 0 YOE / fresh college graduates. ")
            } else {
                append("Focus strictly on 0 to 2 years of experience (Junior / Entry level). ")
            }
            append("Return a valid JSON array of 6 to 8 job objects. Each job object MUST have these exact fields:\n")
            append("{\n")
            append("  \"title\": \"string (e.g. Junior AI Engineer / Applied LLM Engineer)\",\n")
            append("  \"company\": \"string (e.g. Sarvam AI / Mistral / Microsoft / Google / Cohere / Together AI)\",\n")
            append("  \"location\": \"string (e.g. Bengaluru, India or Remote Worldwide)\",\n")
            append("  \"isRemote\": boolean,\n")
            append("  \"experienceLevel\": \"string (e.g. Freshers / 0-1 YOE or 0-2 YOE)\",\n")
            append("  \"minYoe\": 0,\n")
            append("  \"maxYoe\": number (1 or 2),\n")
            append("  \"eligibility\": \"string (e.g. Degree in CS/AI, strong Python, PyTorch, RAG skills)\",\n")
            append("  \"skills\": \"string (comma-separated top 5 skills, e.g. Python, PyTorch, LangChain, Transformers, Docker)\",\n")
            append("  \"directApplyUrl\": \"string (direct URL to careers portal, greenhouse, lever, workday, ashby)\",\n")
            append("  \"postingDate\": \"string (e.g. Today (Verified) or 1 day ago)\",\n")
            append("  \"companyType\": \"string (High-Growth AI Startup or Tech Giant / MNC)\",\n")
            append("  \"salaryBand\": \"string (e.g. ₹15L - ₹22L / yr or $80,000 - $110,000 / yr Remote)\",\n")
            append("  \"descriptionSummary\": \"string (2 sentences explaining role focus and key project)\",\n")
            append("  \"matchScore\": number between 92 and 99\n")
            append("}\n")
            append("Do not wrap in markdown quotes if possible, output raw JSON array.")
        }

        return try {
            val request = GeminiRequest(
                contents = listOf(
                    GeminiContent(parts = listOf(GeminiPart(text = prompt)))
                ),
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.2f,
                    responseMimeType = "application/json"
                )
            )

            val response = apiService.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""
            parseJobsJson(jsonText)
        } catch (e: Exception) {
            e.printStackTrace()
            // On network failure or API limit, return curated data
            CuratedJobsData.getInitialCuratedJobs()
        }
    }

    private fun parseJobsJson(jsonText: String): List<JobPost> {
        val cleanJson = jsonText.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        if (cleanJson.isBlank()) return CuratedJobsData.getInitialCuratedJobs()

        return try {
            val jsonArray = JSONArray(cleanJson)
            val jobs = mutableListOf<JobPost>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                jobs.add(
                    JobPost(
                        id = UUID.randomUUID().toString(),
                        title = obj.optString("title", "AI Engineer"),
                        company = obj.optString("company", "AI Tech Co"),
                        location = obj.optString("location", "India / Remote"),
                        isRemote = obj.optBoolean("isRemote", false),
                        experienceLevel = obj.optString("experienceLevel", "0–2 YOE"),
                        minYoe = obj.optInt("minYoe", 0),
                        maxYoe = obj.optInt("maxYoe", 2),
                        eligibility = obj.optString("eligibility", "Degree in CS or related, Python proficiency"),
                        skills = obj.optString("skills", "Python, PyTorch, Transformers, LLMs"),
                        directApplyUrl = obj.optString("directApplyUrl", "https://careers.google.com"),
                        postingDate = obj.optString("postingDate", "Recent (Verified)"),
                        companyType = obj.optString("companyType", "High-Growth AI Startup"),
                        salaryBand = obj.optString("salaryBand", "Competitive"),
                        descriptionSummary = obj.optString("descriptionSummary", "Exciting entry-level AI role."),
                        source = "Gemini Live Career Search",
                        isVerified = true,
                        matchScore = obj.optInt("matchScore", 95)
                    )
                )
            }
            if (jobs.isEmpty()) CuratedJobsData.getInitialCuratedJobs() else jobs
        } catch (e: Exception) {
            e.printStackTrace()
            CuratedJobsData.getInitialCuratedJobs()
        }
    }
}
