package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DailyDigest
import kotlinx.coroutines.flow.Flow

@Dao
interface DigestDao {
    @Query("SELECT * FROM digests ORDER BY runTimestamp DESC")
    fun getAllDigests(): Flow<List<DailyDigest>>

    @Query("SELECT * FROM digests ORDER BY runTimestamp DESC LIMIT 1")
    fun getLatestDigest(): Flow<DailyDigest?>

    @Query("SELECT * FROM digests ORDER BY runTimestamp DESC LIMIT 1")
    suspend fun getLatestDigestSync(): DailyDigest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDigest(digest: DailyDigest): Long

    @Update
    suspend fun updateDigest(digest: DailyDigest)

    @Query("UPDATE digests SET status = :status WHERE id = :digestId")
    suspend fun updateDigestStatus(digestId: Long, status: String)
}
