package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "jobs")
data class JobPost(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val company: String,
    val location: String,
    val isRemote: Boolean,
    val experienceLevel: String, // "Freshers / 0 YOE", "0-1 YOE", "1-2 YOE"
    val minYoe: Int = 0,
    val maxYoe: Int = 2,
    val eligibility: String,
    val skills: String, // Comma separated list of skills
    val directApplyUrl: String,
    val postingDate: String,
    val companyType: String, // "High-Growth Startup", "Tech Giant / MNC", "AI Research Lab"
    val salaryBand: String = "Competitive",
    val descriptionSummary: String,
    val source: String = "Direct Career Portal",
    val isVerified: Boolean = true,
    val isSaved: Boolean = false,
    val applicationStatus: String = STATUS_NEW, // "NEW", "APPLIED", "INTERVIEWING", "DISMISSED"
    val appliedDate: Long? = null,
    val matchScore: Int = 95,
    val discoveredAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_NEW = "NEW"
        const val STATUS_APPLIED = "APPLIED"
        const val STATUS_INTERVIEWING = "INTERVIEWING"
        const val STATUS_DISMISSED = "DISMISSED"
    }

    fun getSkillList(): List<String> {
        return skills.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }
}
