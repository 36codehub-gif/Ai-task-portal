package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.model.DailyDigest
import com.example.data.model.JobPost
import com.example.data.remote.CuratedJobsData
import com.example.data.remote.GeminiClient
import com.example.email.GmailDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JobRepository(
    private val database: AppDatabase,
    private val preferencesManager: PreferencesManager
) {
    private val jobDao = database.jobDao()
    private val digestDao = database.digestDao()

    val allJobs: Flow<List<JobPost>> = jobDao.getAllJobs()
    val savedJobs: Flow<List<JobPost>> = jobDao.getSavedJobs()
    val latestDigest: Flow<DailyDigest?> = digestDao.getLatestDigest()
    val allDigests: Flow<List<DailyDigest>> = digestDao.getAllDigests()

    suspend fun initializeDataIfNeeded() = withContext(Dispatchers.IO) {
        val totalCount = jobDao.getTotalJobCount()
        if (totalCount == 0) {
            val initialJobs = CuratedJobsData.getInitialCuratedJobs()
            jobDao.insertJobs(initialJobs)

            // Generate initial digest
            val dateStr = SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.US).format(Date())
            val targetEmail = preferencesManager.getTargetEmail()
            val (plainText, htmlText) = GmailDispatcher.generateEmailDigest(
                jobs = initialJobs,
                dateStr = dateStr,
                targetEmail = targetEmail
            )

            val initialDigest = DailyDigest(
                dateString = dateStr,
                headline = "10 Verified Entry-Level AI Engineering Roles (India & Remote)",
                executiveSummary = "Strong opening demand across Sarvam AI, Microsoft, Amazon AWS AI, and Together AI for Freshers and 0–2 YOE engineers.",
                totalJobs = initialJobs.size,
                fresherRolesCount = initialJobs.count { it.minYoe == 0 },
                remoteRolesCount = initialJobs.count { it.isRemote },
                indiaRolesCount = initialJobs.count { it.location.contains("India") },
                topHiringTech = "Python, PyTorch, LangChain, RAG, Transformers, vLLM",
                emailContentHtml = htmlText,
                emailContentText = plainText,
                recipientEmail = targetEmail,
                status = DailyDigest.STATUS_GENERATED,
                runTimestamp = System.currentTimeMillis()
            )
            digestDao.insertDigest(initialDigest)
            preferencesManager.recordRun("Initialized with ${initialJobs.size} verified AI roles")
        }
    }

    suspend fun toggleJobSave(jobId: String, isSaved: Boolean) = withContext(Dispatchers.IO) {
        jobDao.updateSaveStatus(jobId, isSaved)
    }

    suspend fun updateJobApplicationStatus(jobId: String, status: String) = withContext(Dispatchers.IO) {
        val appliedDate = if (status == JobPost.STATUS_APPLIED) System.currentTimeMillis() else null
        jobDao.updateApplicationStatus(jobId, status, appliedDate)
    }

    suspend fun triggerDailySearch(forceLive: Boolean = false): DailyDigest = withContext(Dispatchers.IO) {
        val searchIndia = preferencesManager.isSearchIndia()
        val searchRemote = preferencesManager.isSearchRemote()
        val freshersOnly = preferencesManager.isFilterFreshersOnly()
        val targetEmail = preferencesManager.getTargetEmail()

        val fetchedJobs = try {
            GeminiClient.searchLiveJobs(
                searchIndia = searchIndia,
                searchRemote = searchRemote,
                freshersOnly = freshersOnly
            )
        } catch (e: Exception) {
            CuratedJobsData.getInitialCuratedJobs()
        }

        // Insert new jobs into database
        jobDao.insertJobs(fetchedJobs)

        val dateStr = SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.US).format(Date())
        val (plainText, htmlText) = GmailDispatcher.generateEmailDigest(
            jobs = fetchedJobs,
            dateStr = dateStr,
            targetEmail = targetEmail
        )

        val fresherCount = fetchedJobs.count { it.minYoe == 0 }
        val remoteCount = fetchedJobs.count { it.isRemote }
        val indiaCount = fetchedJobs.count { it.location.contains("India") }

        val newDigest = DailyDigest(
            dateString = dateStr,
            headline = "${fetchedJobs.size} High-Signal AI Engineering Roles Discovered",
            executiveSummary = "Scanned leading startups & MNCs: $fresherCount roles open to Freshers/0 YOE, $remoteCount Remote Worldwide, $indiaCount India tech hubs.",
            totalJobs = fetchedJobs.size,
            fresherRolesCount = fresherCount,
            remoteRolesCount = remoteCount,
            indiaRolesCount = indiaCount,
            topHiringTech = "PyTorch, LangChain, Transformers, RAG, vLLM, FastEmbed",
            emailContentHtml = htmlText,
            emailContentText = plainText,
            recipientEmail = targetEmail,
            status = DailyDigest.STATUS_GENERATED,
            runTimestamp = System.currentTimeMillis()
        )

        val digestId = digestDao.insertDigest(newDigest)
        val finalDigest = newDigest.copy(id = digestId)
        preferencesManager.recordRun("Automation ran: Found ${fetchedJobs.size} fresh roles")
        finalDigest
    }

    suspend fun markDigestSentToGmail(digestId: Long) = withContext(Dispatchers.IO) {
        digestDao.updateDigestStatus(digestId, DailyDigest.STATUS_SENT_GMAIL)
    }

    suspend fun getLatestDigestSync(): DailyDigest? = withContext(Dispatchers.IO) {
        digestDao.getLatestDigestSync()
    }
}
