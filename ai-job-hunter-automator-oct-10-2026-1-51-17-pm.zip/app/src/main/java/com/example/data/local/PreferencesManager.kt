package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("job_scout_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TARGET_EMAIL = "target_email"
        private const val KEY_SCHEDULE_HOUR_IST = "schedule_hour_ist"
        private const val KEY_SCHEDULE_MINUTE_IST = "schedule_minute_ist"
        private const val KEY_AUTOMATION_ENABLED = "automation_enabled"
        private const val KEY_SEARCH_INDIA = "search_india"
        private const val KEY_SEARCH_REMOTE = "search_remote"
        private const val KEY_FILTER_FRESHERS_ONLY = "filter_freshers_only"
        private const val KEY_LAST_RUN_TIME = "last_run_time"
        private const val KEY_LAST_RUN_SUMMARY = "last_run_summary"
        private const val KEY_NOTIFICATION_ENABLED = "notification_enabled"

        const val DEFAULT_EMAIL = "mannewarsachin@gmail.com"
        const val DEFAULT_HOUR_IST = 8
        const val DEFAULT_MINUTE_IST = 0
    }

    private val _targetEmailFlow = MutableStateFlow(getTargetEmail())
    val targetEmailFlow: StateFlow<String> = _targetEmailFlow.asStateFlow()

    private val _automationEnabledFlow = MutableStateFlow(isAutomationEnabled())
    val automationEnabledFlow: StateFlow<Boolean> = _automationEnabledFlow.asStateFlow()

    private val _scheduleTimeFlow = MutableStateFlow(Pair(getScheduleHourIst(), getScheduleMinuteIst()))
    val scheduleTimeFlow: StateFlow<Pair<Int, Int>> = _scheduleTimeFlow.asStateFlow()

    fun getTargetEmail(): String = prefs.getString(KEY_TARGET_EMAIL, DEFAULT_EMAIL) ?: DEFAULT_EMAIL

    fun setTargetEmail(email: String) {
        prefs.edit().putString(KEY_TARGET_EMAIL, email).apply()
        _targetEmailFlow.value = email
    }

    fun getScheduleHourIst(): Int = prefs.getInt(KEY_SCHEDULE_HOUR_IST, DEFAULT_HOUR_IST)
    fun getScheduleMinuteIst(): Int = prefs.getInt(KEY_SCHEDULE_MINUTE_IST, DEFAULT_MINUTE_IST)

    fun setScheduleTimeIst(hour: Int, minute: Int) {
        prefs.edit()
            .putInt(KEY_SCHEDULE_HOUR_IST, hour)
            .putInt(KEY_SCHEDULE_MINUTE_IST, minute)
            .apply()
        _scheduleTimeFlow.value = Pair(hour, minute)
    }

    fun isAutomationEnabled(): Boolean = prefs.getBoolean(KEY_AUTOMATION_ENABLED, true)

    fun setAutomationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTOMATION_ENABLED, enabled).apply()
        _automationEnabledFlow.value = enabled
    }

    fun isSearchIndia(): Boolean = prefs.getBoolean(KEY_SEARCH_INDIA, true)
    fun setSearchIndia(value: Boolean) = prefs.edit().putBoolean(KEY_SEARCH_INDIA, value).apply()

    fun isSearchRemote(): Boolean = prefs.getBoolean(KEY_SEARCH_REMOTE, true)
    fun setSearchRemote(value: Boolean) = prefs.edit().putBoolean(KEY_SEARCH_REMOTE, value).apply()

    fun isFilterFreshersOnly(): Boolean = prefs.getBoolean(KEY_FILTER_FRESHERS_ONLY, false)
    fun setFilterFreshersOnly(value: Boolean) = prefs.edit().putBoolean(KEY_FILTER_FRESHERS_ONLY, value).apply()

    fun getLastRunTime(): Long = prefs.getLong(KEY_LAST_RUN_TIME, 0L)
    fun getLastRunSummary(): String = prefs.getString(KEY_LAST_RUN_SUMMARY, "No runs completed yet") ?: ""

    fun recordRun(summary: String) {
        val now = System.currentTimeMillis()
        prefs.edit()
            .putLong(KEY_LAST_RUN_TIME, now)
            .putString(KEY_LAST_RUN_SUMMARY, summary)
            .apply()
    }

    fun isNotificationEnabled(): Boolean = prefs.getBoolean(KEY_NOTIFICATION_ENABLED, true)
    fun setNotificationEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_NOTIFICATION_ENABLED, enabled).apply()
}
