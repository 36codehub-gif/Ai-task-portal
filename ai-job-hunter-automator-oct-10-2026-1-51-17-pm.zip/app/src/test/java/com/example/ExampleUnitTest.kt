package com.example

import com.example.automation.ScheduleManager
import com.example.data.remote.CuratedJobsData
import com.example.email.GmailDispatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testCuratedJobsCriteria() {
        val jobs = CuratedJobsData.getInitialCuratedJobs()
        assertTrue("Jobs list should not be empty", jobs.isNotEmpty())

        // Check experience criteria: all must be within 0-2 YOE
        jobs.forEach { job ->
            assertTrue("Job ${job.title} minYoe should be >= 0", job.minYoe >= 0)
            assertTrue("Job ${job.title} maxYoe should be <= 2", job.maxYoe <= 2)
            assertNotNull("Direct apply url must exist", job.directApplyUrl)
            assertTrue("Direct apply url must start with http", job.directApplyUrl.startsWith("http"))
        }

        // Verify India and Remote locations exist
        val hasIndia = jobs.any { it.location.contains("India", ignoreCase = true) }
        val hasRemote = jobs.any { it.isRemote }
        assertTrue("Should include India jobs", hasIndia)
        assertTrue("Should include Remote jobs", hasRemote)
    }

    @Test
    fun testGmailDigestFormatting() {
        val jobs = CuratedJobsData.getInitialCuratedJobs()
        val targetEmail = "mannewarsachin@gmail.com"
        val (plainText, htmlText) = GmailDispatcher.generateEmailDigest(
            jobs = jobs,
            dateStr = "Saturday, Oct 10, 2026",
            targetEmail = targetEmail
        )

        // Verify plain text contents
        assertTrue(plainText.contains("mannewarsachin@gmail.com"))
        assertTrue(plainText.contains("8:00 AM IST"))
        assertTrue(plainText.contains("Freshers"))

        // Verify HTML contents
        assertTrue(htmlText.contains("mannewarsachin@gmail.com"))
        assertTrue(htmlText.contains("8:00 AM IST"))
        assertTrue(htmlText.contains("Direct Apply"))
    }

    @Test
    fun testNextTriggerCalculation() {
        val nextTrigger = ScheduleManager.calculateNextTriggerMillis(8, 0)
        assertTrue("Next trigger should be in the future", nextTrigger > System.currentTimeMillis())
    }
}
